package com.songlib;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SongLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
